let ApiURL = "https://email-service-pi.vercel.app"
let BaseURL = process.env.NODE_ENV !== "production" ? 'http://localhost:3000' : "https://bookings.storagex.com.au"

export { ApiURL, BaseURL }




