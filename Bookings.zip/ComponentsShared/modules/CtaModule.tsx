import React from 'react'
import classNames from 'classnames'

type Props = {}

const CtaModule = (props: Props) => {
  return (
    <div>CtaModule</div>
  )
}

export default CtaModule