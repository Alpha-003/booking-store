import React from 'react'
import classNames from 'classnames'

type Props = {}

const MainButton = (props: Props) => {
  return (
    <div>MainButton</div>
  )
}

export default MainButton