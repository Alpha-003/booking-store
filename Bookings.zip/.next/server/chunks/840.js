"use strict";
exports.id = 840;
exports.ids = [840];
exports.modules = {

/***/ 8597:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Box1.5d351694.png","height":200,"width":259,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAA0UlEQVR4nAHGADn/AcHHzwvW1tmb/P3+Kvv9/xEREQ8BGxkY7gYGBdHV08toAbzDyhLT1Nng8fHyDfLy8QAAAAAAMC8vABscGvHOzMgfAcDGzxDCxMfSz83KHevo5f7l5OQASk5RAjY4OOIVFBMtAcnS3xKYlZLi6ebhC0JDQf37+vv/+Pr8BBASF/MWFRUeAf///wNyeYShAf/7Wx4hJQAODQwA8PH0AP7/AKv98+NaAbvE0ABFPDAAp7C9Qvf4+4z+/v7p+fn6gQQC/sjk4+IA1YhpJVMLrwUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 582:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Box2.83b34868.png","height":200,"width":259,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAwklEQVR42mOYOXseAxAXrVizaeOh4xcOX7r5+P6thy9v33zw4uSVmw8DGaZP7APho1P6ev9Pnjrn/7yFK/5Pmjr7/8btB/6fvniriKGiphWE1yWnZv/3tNH75RKQ8M/Xzfd3W23l/007DkUxFFU0gfDatIy8/0kpUT+z44P+NDe0/5vQ1vK/INo5hKG8thWEm9Nyyv5nJ8X+r04J+F9UUPq/d9LsPU4MDCoMIFDZ0AnCnoVljSdTsssXu4WmGtozQAAAuNFlVLw8I0wAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 4769:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Box3.d2f0469c.png","height":243,"width":315,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAYAAAD+Bd/7AAAAu0lEQVR42mMAgeOnr7B3dPYpZKWn2OYXFKeU5GU31NXUJM6cs9CSoby8ujImKvK5q4vLp4yMjP8lZdX/U+Lj/kcE+f1v6+p7xpCbmz/V2d7mv6Otxb+AkMi/KQkJP2N9bL4n+Vv9r8xLfcqQmpzUFhqT/j8yveJ/vJva/+Cw+P82PvH/Q91t3hUlBPYz5GckyRbUdHdmV3S9KMnOeJaaWTw3PqvKzzO1jocBGfS1Vgu5V80TQharSXJhBgBm500UYlPWzAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 7557:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ navbar_Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/images/Logo.png
/* harmony default export */ const Logo = ({"src":"/_next/static/media/Logo.fb2a3ef2.png","height":47,"width":236,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAQAAADPnVVmAAAAKElEQVR42gXAsQ0AEBAAwJuAUH2JRBQKK+otLTxTEbKqaFxbMoTl6B8uQAKWe/XBkAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/io5"
var io5_ = __webpack_require__(9989);
;// CONCATENATED MODULE: ./ComponentsShared/navbar/Navbar.tsx






const Navbar = (props)=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between  items-center px-6 sm:px-20 py-[24px] bg-primary ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "https://storagex.com.au/",
                className: " cursor-pointer",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: Logo,
                    alt: "Logo Image",
                    placeholder: "blur",
                    priority: true,
                    blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAAyCAYAAACqECmXAAAAu0lEQVR42u3VMQ0AMAgAsKF8Pzc28MiFCJLWRCOr/wMATguhA4DQAQChAwBCBwCEDgBCBwCEDgAIHQAQOgAIHQAQOgAgdABA6AAgdABA6ACA0AEAoQOA0AEAoQMAQgcAhA4AQgcAhA4ACB0AEDoACB0AEDoAIHQAQOgAIHQAQOgAgNABAKEDgNABAKEDAEIHAIQOAEIHAIQOAAgdABA6AAhd6AAgdABA6ACA0AEAoQOA0AEAoQMAQgcA1gAumHKnLUkH+gAAAABJRU5ErkJggg=="
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "tel:03-4328-5546",
                children: /*#__PURE__*/ jsx_runtime_.jsx(io5_.IoCall, {
                    className: "text-white text-[30px] sm:text-[40px] cursor-pointer"
                })
            })
        ]
    });
};
/* harmony default export */ const navbar_Navbar = (Navbar);


/***/ }),

/***/ 517:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_2__]);
react_toastify__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const NotifyComp = (props)=>{
    let [FirstRender, setFirstRender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    function notify(text, Type) {
        (0,react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast)(text, {
            type: Type
        });
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (FirstRender) {
            setFirstRender(false);
        } else {
            if (props.toggle) {
                notify(props.text, props.type);
                props.toggleSetter(false);
            }
        }
    }, [
        props.toggle
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {})
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotifyComp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9377:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(983);
/* harmony import */ var react_datepicker__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_datepicker__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5994);
/* harmony import */ var react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_datepicker_dist_react_datepicker_css__WEBPACK_IMPORTED_MODULE_4__);





const Input = (props)=>{
    function getHoursAndMinutes(date = new Date()) {
        return padTo2Digits(date.getHours()) + ":" + padTo2Digits(date.getMinutes()) + ":" + padTo2Digits(date.getSeconds());
    }
    function padTo2Digits(num) {
        return String(num).padStart(2, "0");
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative group  w-full  h-[40px] " + " " + (props.size == "medium" ? MedInput : props.size == "large" ? LargeInput : "w-full"),
        children: [
            props.textarea ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                id: props.name,
                ...props.register(props.name),
                placeholder: " ",
                maxLength: 400,
                className: input + " resize-none  -z-10 ",
                style: {
                    height: "100px"
                }
            }) : props.type == "datePicker" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_datepicker__WEBPACK_IMPORTED_MODULE_3___default()), {
                selected: props.startDate,
                onChange: (date)=>{
                    const year = date.getFullYear();
                    const month = padTo2Digits(date.getMonth() + 1);
                    const day = padTo2Digits(date.getDate());
                    const withHyphens = [
                        year,
                        month,
                        day
                    ].join("-");
                    const hoursAndMinutes = getHoursAndMinutes(date);
                    props.setDateYMD(withHyphens);
                    props.setStartDate(date);
                },
                minDate: new Date(),
                customInput: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    id: props.name,
                    placeholder: " ",
                    type: props.type,
                    className: input + "mt-8" + (props.error && Error)
                }),
                placeholderText: "Select a date after 5 days ago"
            }) : props.type == "checkBox" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                id: props.name,
                ...props.register(props.name),
                placeholder: " ",
                type: props.type,
                className: input + "  " + (props.error && Error)
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                id: props.name,
                ...props.register(props.name),
                defaultValue: props.defaultValue ? props.defaultValue : "",
                placeholder: " ",
                type: props.type,
                className: input + "  " + (props.error && Error)
            }),
            props.error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-red-500 text-xs font-bold w-[100%] ml-2",
                children: props.error.message
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                className: label,
                children: [
                    props.placeholder,
                    props.required && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xl font-bold",
                        children: "*"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Input);
const input = classnames__WEBPACK_IMPORTED_MODULE_1___default()("block py-4 px-2 w-full text-md  rounded-lg border-2 border-gray-600 appearance-none    focus:outline-none focus:ring-0 focus:border-[#e6b42d] peer  ");
const label = classnames__WEBPACK_IMPORTED_MODULE_1___default()("pointer-events-none  px-3 peer-focus:font-medium peer-focus: absolute text-xl text-gray-400   duration-300 transform -translate-y-9 left-1 scale-75 top-2  origin-[0] peer-focus:left-1 peer-focus:text-[#e6b42d]  peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-10");
const MedInput = classnames__WEBPACK_IMPORTED_MODULE_1___default()("w-[13vw]");
const LargeInput = classnames__WEBPACK_IMPORTED_MODULE_1___default()("w-[25vw]");
const Error = classnames__WEBPACK_IMPORTED_MODULE_1___default()("border-red-500");


/***/ })

};
;