(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 8809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ modal_Modal)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-dom"
var external_react_dom_ = __webpack_require__(6405);
var external_react_dom_default = /*#__PURE__*/__webpack_require__.n(external_react_dom_);
;// CONCATENATED MODULE: external "react-remove-scroll-bar"
const external_react_remove_scroll_bar_namespaceObject = require("react-remove-scroll-bar");
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
;// CONCATENATED MODULE: ./ComponentsShared/modal/Modal.tsx






function Modal(props) {
    const [isBrowser, setIsBrowser] = (0,external_react_.useState)(false);
    let ModalRef = (0,external_react_.useRef)(null);
    // const modalRoot = document?.getElementById("modal");
    (0,external_react_.useEffect)(()=>{
        setIsBrowser(true);
    }, []);
    //ON CLICK OUTSIDE OF MODAL
    (0,external_react_.useEffect)(()=>{
        function handleClickOutside(event) {
            if (ModalRef.current && !ModalRef.current.contains(event.target)) {
                props.SetOpen(false);
                if (props.SetVideoPictureApear) {
                    props.SetVideoPictureApear(true);
                }
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        ModalRef
    ]);
    /////////////////////////////////////////
    //Modal component is rendered in the document.tsx file
    const ModalContent = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: ModalWrapper + " " + (props === null || props === void 0 ? void 0 : props.ExtraClass),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_remove_scroll_bar_namespaceObject.RemoveScrollBar, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative h-[100%] overflow-y-auto overflow-x-hidden lg:overflow-hidden",
                ref: ModalRef,
                children: [
                    props.CloseBtn && /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiOutlineClose, {
                        className: "cursor-pointer absolute w-11 top-2 right-2 p-1 bg-[#e6b42d] rounded-full mr-2 mt-2 z-50",
                        color: props.CloseBtnColor ? props.CloseBtnColor : "black",
                        onClick: ()=>{
                            props.CloseBtnFunc ? props.CloseBtnFunc() : props.SetOpen(false);
                        },
                        fontSize: 30
                    }),
                    props.children
                ]
            })
        ]
    });
    /////////////////////////////////////////////////
    if (isBrowser && (document === null || document === void 0 ? void 0 : document.getElementById("modal"))) {
        return /*#__PURE__*/ external_react_dom_default().createPortal(ModalContent, document.getElementById("modal"));
    } else {
        return null;
    }
}
/* harmony default export */ const modal_Modal = (Modal);
const ModalWrapper = external_classnames_default()("fixed z-[2000]   top-0  left-0  w-full  h-full   bg-gray-900  bg-opacity-50  flex  justify-center  items-center");


/***/ }),

/***/ 2094:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Components_input_Input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9377);
/* harmony import */ var _ComponentsShared_modal_Modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8809);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5641);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1908);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _context_DataContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8034);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _ComponentsShared_notify_NotifyComp__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(517);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__, _ComponentsShared_notify_NotifyComp__WEBPACK_IMPORTED_MODULE_11__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_5__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__, _ComponentsShared_notify_NotifyComp__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const PersonalFormSchema = yup__WEBPACK_IMPORTED_MODULE_6__.object({
    firstName: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("required"),
    lastName: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("required"),
    email: yup__WEBPACK_IMPORTED_MODULE_6__.string().email().required("required"),
    phoneNumber: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("required").matches(/^[0-9]+$/, "Must be only digits")
});
const OrginzationFormSchema = yup__WEBPACK_IMPORTED_MODULE_6__.object({
    firstName: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("required"),
    lastName: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("required"),
    email: yup__WEBPACK_IMPORTED_MODULE_6__.string().email().required("required"),
    phoneNumber: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("required").matches(/^[0-9]+$/, "Must be only digits"),
    companyName: yup__WEBPACK_IMPORTED_MODULE_6__.string().required("required"),
    ABN: yup__WEBPACK_IMPORTED_MODULE_6__.string().notRequired().nullable().transform((value)=>value ? value : null).matches(/^[0-9]+$/, "Must be only digits").min(11, "Must be exactly 11 digits").max(11, "Must be exactly 11 digits")
});
const CompanyFormSchema = yup__WEBPACK_IMPORTED_MODULE_6__.object({
    furtherInfo: yup__WEBPACK_IMPORTED_MODULE_6__.string()
});
const Form = (props)=>{
    const { register: PersonalRegister , handleSubmit , formState: { errors: PersonalErrors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)({
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__.yupResolver)(PersonalFormSchema)
    });
    const { register: OrginzationRegister , handleSubmit: OrginzationSubmit , formState: { errors: OrginzationErrors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)({
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__.yupResolver)(OrginzationFormSchema)
    });
    const { register: CompanyRegister , handleSubmit: FinalSubmit , formState: { errors: CompanyErrors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_5__.useForm)({
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_7__.yupResolver)(CompanyFormSchema)
    });
    const { setOpenCTA , SelectedUnit  } = react__WEBPACK_IMPORTED_MODULE_4___default().useContext(_context_DataContext__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z);
    const [SecondStep, setSecondStep] = react__WEBPACK_IMPORTED_MODULE_4___default().useState(false);
    const [FirstPhaseData, setFirstPhaseData] = react__WEBPACK_IMPORTED_MODULE_4___default().useState();
    const [FinalData, setFinalData] = react__WEBPACK_IMPORTED_MODULE_4___default().useState();
    const [Submitted, setSubmitted] = react__WEBPACK_IMPORTED_MODULE_4___default().useState(false);
    const [Loading, setLoading] = react__WEBPACK_IMPORTED_MODULE_4___default().useState(false);
    const [Error, setError] = react__WEBPACK_IMPORTED_MODULE_4___default().useState("");
    const [startDate, setStartDate] = react__WEBPACK_IMPORTED_MODULE_4___default().useState(new Date());
    const [DateYMD, setDateYMD] = react__WEBPACK_IMPORTED_MODULE_4___default().useState("");
    const [Toggle, setToggle] = react__WEBPACK_IMPORTED_MODULE_4___default().useState(false);
    // console.log(startDate);
    const [isOrginzation, setisOrginzation] = react__WEBPACK_IMPORTED_MODULE_4___default().useState(false);
    console.log(isOrginzation);
    function FirstPhaseSubmit(data) {
        if (!PersonalErrors.firstName && !PersonalErrors.lastName && !PersonalErrors.email && !PersonalErrors.phoneNumber) {
            setFirstPhaseData(data);
            setSecondStep(true);
        }
    }
    function FirstPhaseSubmitOrginzation(data) {
        if (!OrginzationErrors.companyName && !OrginzationErrors.ABN && !OrginzationErrors.firstName && !OrginzationErrors.lastName && !OrginzationErrors.email && !OrginzationErrors.phoneNumber) {
            setFirstPhaseData(data);
            setSecondStep(true);
        }
    }
    function padTo2Digits(num) {
        return String(num).padStart(2, "0");
    }
    async function SecondPhaseSubmit(data) {
        try {
            setLoading(true);
            let CompanyData = {};
            if (!CompanyErrors.futherInfo) {
                if (DateYMD.length == 0) {
                    let date = new Date();
                    const year = date.getFullYear();
                    const month = padTo2Digits(date.getMonth() + 1);
                    const day = padTo2Digits(date.getDate());
                    const withHyphens = [
                        year,
                        month,
                        day
                    ].join("-");
                    CompanyData = {
                        ...data,
                        DatePicker: withHyphens
                    };
                } else {
                    CompanyData = {
                        ...data,
                        DatePicker: DateYMD
                    };
                }
                //@ts-ignore
                let FinalData = {
                    ...FirstPhaseData,
                    ...CompanyData
                };
                ////Adding LEAD
                let TestData = {
                    contact_type: isOrginzation ? "ORGANISATION" : "INDIVIDUAL",
                    full_name: isOrginzation ? FinalData === null || FinalData === void 0 ? void 0 : FinalData.companyName : `${FinalData === null || FinalData === void 0 ? void 0 : FinalData.firstName} ${FinalData === null || FinalData === void 0 ? void 0 : FinalData.lastName}`,
                    contact_name: `${FinalData === null || FinalData === void 0 ? void 0 : FinalData.firstName} ${FinalData === null || FinalData === void 0 ? void 0 : FinalData.lastName}`,
                    contact_email: FinalData.email,
                    contact_phone_mobile: FinalData.phoneNumber,
                    //@ts-ignore
                    expected_movein_at: FinalData.DatePicker,
                    lead_source: "Website",
                    contact_category: "Web Site",
                    customer_type: isOrginzation ? "Commercial" : "Residential"
                };
                const requestOptions = {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        "Authorization": `Bearer ${"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1MiIsImp0aSI6IjVhZjRjMTYyMjcyNmE4MzM0MGIzM2JmNzc4Y2MxY2JhNWViNjJjMzkzMGFhNWQ1MzMzMTdkNmQ3M2MxMmNjNDJmMDhkNTNlMjhlNTgwMTJiIiwiaWF0IjoxNjgxMzUyMTkwLjEyMTY5MSwibmJmIjoxNjgxMzUyMTkwLjEyMTY5MywiZXhwIjoxNzEyOTc0NTkwLjA5MzA2MSwic3ViIjoiMjEyNSIsInNjb3BlcyI6W119.BrmmVaxILgo-AwFIJfzhurK5yTvNIufTZj8hZP4Ji5U0APnmPy0n9lX6HiXOukM-lA-ydFh1PvgJr4R6YSSX-KS1_Jyrzsq3JOtnyQG-5NCfgpUKXVPRlVdeyR9JFI9cOhGnhUpfTSh0t3WaMxv_DCgFY044mH3ABUR9IGTDLzSod71g5Hch7KQaqmWVnQO1QCdy5P79X_5kCtsd0fvH7bK-JjdQEQP848nPcuRwHP_5pT97If23YIGLHAZjYt0-n8oXJsAokKrmPsjzjVxYIeZvOza5sTL1GMJcZIZdgWD-zVTUDXHckf_-BvTmd0VRlrcqo_Pr-INqI7Mg_3Z2fzkG06w7zSqpDDg-m0yuopr4GrozVs0_WbRRWnlGA96bnXIi4h06JWbVtEHJ0FPmDZPpek8NptqvsPPPSYv20NcV-dWRmmhZYCwBLSuE2Urzildr99FDJ7857Vtu85tb-NZbpCOG6KAE4yb9yyyTU7jP2FlAAzaB-O5KURWBwHIO5dbfBSFxPTGEOXtNddm42doL4E1tKfSUim4ZLMjjuXdPeQIh9NiCOpceC5q9Iw7MacgYuYs6QptGBj2S-nvD_SrxGV3Q4efa2pnV444STmLls16lXvPSN99aLrFErg6adLRGf9ULJBP8V5HULhWsnFps4kqcErskylys7LSiQSE"}`
                    },
                    body: JSON.stringify(TestData)
                };
                let responseLead = await fetch(`${"https://cloud.storman.com/api/v1/facility/XSTOR"}/leads`, requestOptions);
                let Lead = await responseLead.json();
                if (!Lead.success) {
                    //@ts-ignore
                    // console.log(Lead.message)
                    //@ts-ignore
                    // notify(Lead.message ? Lead.message : "Error", 'error')
                    setError(Lead.message ? Lead.message : "Try again later");
                    setToggle(true);
                    setLoading(false);
                } else {
                    let LeadID = Lead.data.lead_id;
                    ////Adding Qoute
                    let QouteData = {
                        lead_id: LeadID,
                        unit_type_code: SelectedUnit.code,
                        price: SelectedUnit.monthly_rack_rate,
                        quantity: 1,
                        //@ts-ignore
                        note: FinalData.futherInfo
                    };
                    const requestOptionsQoute = {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "Accept": "application/json",
                            "Authorization": `Bearer ${"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1MiIsImp0aSI6IjVhZjRjMTYyMjcyNmE4MzM0MGIzM2JmNzc4Y2MxY2JhNWViNjJjMzkzMGFhNWQ1MzMzMTdkNmQ3M2MxMmNjNDJmMDhkNTNlMjhlNTgwMTJiIiwiaWF0IjoxNjgxMzUyMTkwLjEyMTY5MSwibmJmIjoxNjgxMzUyMTkwLjEyMTY5MywiZXhwIjoxNzEyOTc0NTkwLjA5MzA2MSwic3ViIjoiMjEyNSIsInNjb3BlcyI6W119.BrmmVaxILgo-AwFIJfzhurK5yTvNIufTZj8hZP4Ji5U0APnmPy0n9lX6HiXOukM-lA-ydFh1PvgJr4R6YSSX-KS1_Jyrzsq3JOtnyQG-5NCfgpUKXVPRlVdeyR9JFI9cOhGnhUpfTSh0t3WaMxv_DCgFY044mH3ABUR9IGTDLzSod71g5Hch7KQaqmWVnQO1QCdy5P79X_5kCtsd0fvH7bK-JjdQEQP848nPcuRwHP_5pT97If23YIGLHAZjYt0-n8oXJsAokKrmPsjzjVxYIeZvOza5sTL1GMJcZIZdgWD-zVTUDXHckf_-BvTmd0VRlrcqo_Pr-INqI7Mg_3Z2fzkG06w7zSqpDDg-m0yuopr4GrozVs0_WbRRWnlGA96bnXIi4h06JWbVtEHJ0FPmDZPpek8NptqvsPPPSYv20NcV-dWRmmhZYCwBLSuE2Urzildr99FDJ7857Vtu85tb-NZbpCOG6KAE4yb9yyyTU7jP2FlAAzaB-O5KURWBwHIO5dbfBSFxPTGEOXtNddm42doL4E1tKfSUim4ZLMjjuXdPeQIh9NiCOpceC5q9Iw7MacgYuYs6QptGBj2S-nvD_SrxGV3Q4efa2pnV444STmLls16lXvPSN99aLrFErg6adLRGf9ULJBP8V5HULhWsnFps4kqcErskylys7LSiQSE"}`
                        },
                        body: JSON.stringify(QouteData)
                    };
                    let responseQoute = await fetch(`${"https://cloud.storman.com/api/v1/facility/XSTOR"}/quote-lines`, requestOptionsQoute);
                    let QouteAdded = await responseQoute.json();
                    if (!QouteAdded.success) {
                        //@ts-ignore
                        // console.log(QouteAdded.message)
                        //@ts-ignore
                        setError(QouteAdded.message ? QouteAdded.message : "Try again later");
                        setToggle(true);
                        setLoading(false);
                    } else {
                        // let EmailData = {
                        //   email: "mohamedsalem52@outlook.com",
                        //   name: 'Standefy'
                        // }
                        // const requestOptionsEmail = {
                        //   method: 'POST',
                        // };
                        // //@ts-ignore
                        // fetch(`https://email-service-pi.vercel.app/email`, requestOptionsEmail)
                        //////////////Saving to localStorage the FinalData and the LEadID /////
                        let DataToStore = {
                            ...FinalData,
                            LeadID,
                            ...SelectedUnit
                        };
                        // console.log("//////////////////")
                        // console.log("Initial DataToStore which will be added to the localstorage")
                        // console.log(DataToStore)
                        // console.log("//////////////////")
                        localStorage.setItem("DataToStore", JSON.stringify(DataToStore));
                        // console.log(TestData);
                        // console.log(LeadData);
                        setLoading(false);
                        setSubmitted(true);
                    }
                }
            //////////////Sending Email/////
            }
        } catch (error) {
            // console.log("I am error")
            // console.log(error)
            //@ts-ignore
            setError(error.message ? error.message : "Error");
            setToggle(true);
            setLoading(false);
        }
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ComponentsShared_notify_NotifyComp__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                toggleSetter: setToggle,
                type: "error",
                text: Error,
                toggle: Toggle
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ComponentsShared_modal_Modal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                CloseBtn: true,
                CloseBtnColor: "white",
                SetOpen: setOpenCTA,
                children: [
                    !Submitted && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `w-[100vw] bg-[#1a1a1a] text-white sm:w-[80vw]  lg:h-[100vh] lg:w-[60vw] xl:w-[40vw] flex flex-col items-center  justify-center rounded-lg  overflow-hidden `,
                        children: [
                            SecondStep ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center text-center ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_8__.MdArrowBackIosNew, {
                                        onClick: ()=>setSecondStep(false),
                                        className: "absolute top-3 left-4 p-2 bg-[#e6b42d] rounded-full cursor-pointer ",
                                        size: 35
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                        className: "text-2xl mb-20 pt-20 ",
                                        children: [
                                            "We are excited to see you ",
                                            FirstPhaseData === null || FirstPhaseData === void 0 ? void 0 : FirstPhaseData.firstName,
                                            " !"
                                        ]
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-2xl mb-4 pt-10",
                                children: SecondStep ? "Move in Date" : "Contact Info"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                className: FormContainer + " " + (SecondStep ? Hidden : Shown),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center gap-4 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-white text-2xl ",
                                                children: "Organization: "
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center ",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "default-radio-2",
                                                                type: "radio",
                                                                value: "",
                                                                checked: isOrginzation,
                                                                onChange: ()=>setisOrginzation((prev)=>{
                                                                        if (prev === false) {
                                                                            return true;
                                                                        } else {
                                                                            return false;
                                                                        }
                                                                    }),
                                                                name: "default-radio",
                                                                className: "w-6 h-6 cursor-pointer "
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "default-radio-1",
                                                                className: "ml-2 text-lg font-medium text-gray-900 dark:text-gray-300",
                                                                children: "Yes"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                onChange: ()=>setisOrginzation((prev)=>{
                                                                        if (prev === true) {
                                                                            return false;
                                                                        } else {
                                                                            return true;
                                                                        }
                                                                    }),
                                                                checked: !isOrginzation,
                                                                id: "default-radio-1",
                                                                type: "radio",
                                                                value: "",
                                                                name: "default-radio",
                                                                className: "w-6 h-6 cursor-pointer"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "default-radio-2",
                                                                className: "ml-2 text-lg font-medium text-gray-900 dark:text-gray-300",
                                                                children: "No"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    isOrginzation ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex w-full gap-4 mb-4",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        error: OrginzationErrors.companyName,
                                                        register: OrginzationRegister,
                                                        name: "companyName",
                                                        required: true,
                                                        type: "text",
                                                        placeholder: "Company name",
                                                        size: "medium"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        error: OrginzationErrors.ABN,
                                                        register: OrginzationRegister,
                                                        name: "ABN",
                                                        type: "text",
                                                        placeholder: "ABN (optional)",
                                                        size: "medium"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex w-full gap-4 mb-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        error: OrginzationErrors.firstName,
                                                        register: OrginzationRegister,
                                                        name: "firstName",
                                                        required: true,
                                                        type: "text",
                                                        placeholder: "First name",
                                                        size: "medium"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        error: OrginzationErrors.lastName,
                                                        register: OrginzationRegister,
                                                        name: "lastName",
                                                        required: true,
                                                        type: "text",
                                                        placeholder: "Last name",
                                                        size: "medium"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                error: OrginzationErrors.email,
                                                register: OrginzationRegister,
                                                name: "email",
                                                required: true,
                                                type: "email",
                                                placeholder: "email",
                                                size: "full"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                error: OrginzationErrors.phoneNumber,
                                                register: OrginzationRegister,
                                                name: "phoneNumber",
                                                type: "text",
                                                required: true,
                                                placeholder: "Phone number",
                                                size: "full"
                                            })
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                error: PersonalErrors.firstName,
                                                register: PersonalRegister,
                                                name: "firstName",
                                                required: true,
                                                type: "text",
                                                placeholder: "First name",
                                                size: "medium"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                error: PersonalErrors.lastName,
                                                register: PersonalRegister,
                                                name: "lastName",
                                                required: true,
                                                type: "text",
                                                placeholder: "Last name",
                                                size: "medium"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                error: PersonalErrors.email,
                                                register: PersonalRegister,
                                                name: "email",
                                                required: true,
                                                type: "email",
                                                placeholder: "email",
                                                size: "full"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                error: PersonalErrors.phoneNumber,
                                                register: PersonalRegister,
                                                name: "phoneNumber",
                                                type: "text",
                                                required: true,
                                                placeholder: "Phone number ",
                                                size: "full"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "button",
                                        onClick: isOrginzation ? OrginzationSubmit(FirstPhaseSubmitOrginzation) : handleSubmit(FirstPhaseSubmit),
                                        className: FormMainButton,
                                        children: "Next Step"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                className: FormContainer + " " + (!SecondStep ? Hidden : Shown),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        setDateYMD: setDateYMD,
                                        startDate: startDate,
                                        setStartDate: setStartDate,
                                        type: "datePicker",
                                        required: true,
                                        placeholder: "Pick your move in date now",
                                        size: "full"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_input_Input__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        error: CompanyErrors.futherInfo,
                                        register: CompanyRegister,
                                        name: "futherInfo",
                                        type: "text",
                                        required: false,
                                        textarea: true,
                                        placeholder: "Anything else we should know?",
                                        size: "full"
                                    }),
                                    Loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mt-14",
                                        role: "status",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                "aria-hidden": "true",
                                                className: "w-8 h-8 mr-2 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600",
                                                viewBox: "0 0 100 101",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                                                        fill: "currentColor"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                                                        fill: "currentFill"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "sr-only",
                                                children: "Loading..."
                                            })
                                        ]
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex flex-col w-[100%] items-center text-center gap-6 mt-14",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            onClick: FinalSubmit(SecondPhaseSubmit),
                                            className: FormMainButton,
                                            children: "Submit"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    Submitted && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `w-[100vw]  bg-[#1a1a1a] text-white  h-[60%]  sm:w-[80vw] lg:w-[60vw] xl:w-[40vw] overflow-hidden relative      rounded-lg  `,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "border-b-2 border-gray-500 flex flex-col items-center py-10 ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-2xl mt-4 z-20 relative mb-4 text-center pt-10",
                                        children: "Complete your reservation now!"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        onClick: ()=>setOpenCTA(false),
                                        href: "/Reservation",
                                        className: "text-md font-bold uppercase animate-text text-center mt-2 bg-gradient-to-r from-[#e6b42d] via-[#ffbd08] to-[#030200] px-2 py-4 rounded-lg ",
                                        children: "Complete Reservation"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    className: "text-lg px-10 text-gray-400 mt-4 z-20 relative mb-4 text-center pt-10",
                                    children: "If you prefer to complete your reservation through direct communication, we can contact you soon to finalize the details. "
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Form);
const FormContainer = classnames__WEBPACK_IMPORTED_MODULE_3___default()(" w-[90%] h-full  flex flex-col justify-center  items-center text-black    gap-14 ");
const FormMainButton = classnames__WEBPACK_IMPORTED_MODULE_3___default()("px-2  text-white py-4 w-[100vw] md:w-[100%] text-lg  bg-[#e6b42d]  transition-all  duration-700 rounded-md hover:bg-[#cfa229]   text-center hover:shadow-lg hover:shadow-[#e6b42d] hover:tracking-widest   ");
const Hidden = classnames__WEBPACK_IMPORTED_MODULE_3___default()("opacity-0 translate-x-[600px] absolute  w-0 h-0  pointer-events-none blur  transition-transform  duration-500  ");
const Shown = classnames__WEBPACK_IMPORTED_MODULE_3___default()("opacity-1 translate-x-0  blur-0  transition-transform duration-500 ");
const CardSuccessCont = classnames__WEBPACK_IMPORTED_MODULE_3___default()("flex flex-col gap-4  items-center w-[100%]");
const CardSuccess = classnames__WEBPACK_IMPORTED_MODULE_3___default()("  pt-2  w-[100%] flex   justify-center flex-col items-center  boxshadow  border-2 border-black transition-all    rounded-md  bg-gray-400  bg-clip-padding backdrop-filter backdrop-blur-lg bg-opacity-10 ");
const CardTitle = classnames__WEBPACK_IMPORTED_MODULE_3___default()("font-bold   text-lg mt-4 mb-2");
const CardDesc = classnames__WEBPACK_IMPORTED_MODULE_3___default()("text-md  mb-4 text-center");

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5064:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ hero_Hero)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./public/images/HeroImage.png
/* harmony default export */ const HeroImage = ({"src":"/_next/static/media/HeroImage.2fe7ae6a.png","height":537,"width":1478,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAIAAAAhqtkfAAAAU0lEQVR42mNw9gjTUNdUlhVztVOIDDQJDfIJDo4KColl8AiIUVRW52Djszbm83SQtTTkUVbVdfPwZQgKDBYWEuDlFdTTkNLTUtdUU9JUVzbQ1wIAS94OPGdDJiIAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
;// CONCATENATED MODULE: ./Components/hero/Hero.tsx






const Hero = (props)=>{
    function ScrolltoRef() {
        if (props.toJumpRef.current === null) return;
        props.toJumpRef.current.scrollIntoView({
            behavior: "smooth"
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: HeroImage,
                alt: "Image of our building",
                className: "h-[400px] w-[100vw]"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute top-[40%] translate-y-[-50%] ml-20",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-4xl sm:text-5xl text-white font-bold mb-2 lg:text-6xl ",
                        children: "South East Melbourne"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-lg sm:text-xl lg:w-[80%] text-white mb-4 lg:text-2xl ",
                        children: "Servicing: Oakleigh, Clayton, Chadstone, Huntingdale, Mount Waverley and all neighbouring suburbs"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsArrowDownCircle, {
                        onClick: ScrolltoRef,
                        size: 40,
                        color: "#E6B42D",
                        className: "text-center animate-bounce cursor-pointer "
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const hero_Hero = (Hero);
const HeroText = external_classnames_default()(" text-6xl");


/***/ }),

/***/ 2977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ locationInfo_LocationInfo)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/ai"
var ai_ = __webpack_require__(9847);
;// CONCATENATED MODULE: external "react-icons/im"
const im_namespaceObject = require("react-icons/im");
// EXTERNAL MODULE: external "react-icons/md"
var md_ = __webpack_require__(4041);
// EXTERNAL MODULE: external "react-icons/si"
var si_ = __webpack_require__(764);
// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__(3559);
;// CONCATENATED MODULE: external "react-responsive-carousel"
const external_react_responsive_carousel_namespaceObject = require("react-responsive-carousel");
;// CONCATENATED MODULE: ./public/images/ImagePeople.png
/* harmony default export */ const ImagePeople = ({"src":"/_next/static/media/ImagePeople.62f4fe7b.png","height":450,"width":568,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAnklEQVR42mPYOC9y/oSgKe2hbbWh5UWhmWkhUTGhASFhDHN6Qqf15vS3JDdUJBbkpyalp4WGR3h4uDLUZltO7q6aOqm9vqZsYn9/Z2dXeUmhu5M1Q6SPnqulaFlpUUtLC1C4rDDP3lLL28WeQVOSITsrtamxoaWpsb+3p7WlOTszw9rYgMHOXMNYW9zT2drPy9nWQldckEdXQcxKTxEAv842gbLpIG0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/ImagePeople2.png
/* harmony default export */ const ImagePeople2 = ({"src":"/_next/static/media/ImagePeople2.0c06a702.png","height":450,"width":568,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAoUlEQVR42gGWAGn/ALOdZLijZsCoZ8atZ8yxaNK1ac2vYNK0ZACDeFp8a0iVh2ObjWWfj2Knl2eegkqmjlQATk1JZF9bmpiUlpSPnJmSpaKbjoNse2cxACcuLX5+fo6Mi4yLi4uHhI2JhoiDfUY2FAAmKys1ODhRT0xVT0lUTENRSEBVTT1HQDAAKiwsAg4TLisoOi0iPTQqOTErHh4eMC4ssrc6xzLM5W0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/ImagePeople3.png
/* harmony default export */ const ImagePeople3 = ({"src":"/_next/static/media/ImagePeople3.0478d978.png","height":450,"width":563,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAoUlEQVR42gGWAGn/ALGTPrmdTcyyY8atYcGqYbqkXbSfWrCcWQCGcDGql16gjFWTf0iaiVSThVKThliKfFAAdGtVsauapqGUmpWInZmLl5WJoqGYdXFjAE5KP5KQiZGQjIaFgZSUko+QjoyNjFdZVgAgGhU7NC46NC9DQkBIRkM+Pj5DRkU+PTgAIxgLJBMAKRsLNDEqKh4OFQMAExINLiokqA858QN1tPwAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./public/images/ImagePeople4.png
/* harmony default export */ const ImagePeople4 = ({"src":"/_next/static/media/ImagePeople4.702c0671.png","height":450,"width":568,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGCAIAAABxZ0isAAAAn0lEQVR42mPoqbQtCBdpyNJd1Ok+sdyqKV19SoPD2tnRDB7Ohg5afM6WmskJPoFuej6W8i52uvExngxqaqoMDAw+Pj4trW2NTU3FxcV6umr2zi4MLvamGvK8pcWF7W2tnR3tEydNjI4KszbVZjDXVzFSlzLVVbGzMHF1cQgK9rO1MbOzNmXQkObTkOHTU5NRlhWUEueXl+A2MdQ0NtQGAF2oKC9RzdEtAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./Components/locationInfo/LocationInfo.tsx







 // requires a loader






const LocationInfo = (props)=>{
    let array = [
        ImagePeople,
        ImagePeople2,
        ImagePeople3,
        ImagePeople4
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col-reverse lg:flex lg:flex-row lg:gap-10 ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: Container,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-2xl mt-10 mb-2 sm:text-4xl sm:mt-20 lg:text-5xl lg:mb-4",
                        children: "Storage South East Melbourne"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-md sm:text-lg ",
                        children: "At StorageX, we offer diverse storage units in multiple sizes and specialty storage to fit your needs, whether you're moving, running out of space, or need to store a prized possession. Our team is always ready to help, ensuring a stress-free experience"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: mainDataContainer,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: miniDataBox,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: titleIcon,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(im_namespaceObject.ImLocation2, {
                                                size: 20,
                                                className: Icon
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: Title,
                                                children: "Address"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: Desc,
                                        children: "1313-1315 North Road Huntingdale,Victoria 3166"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: miniDataBox,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: titleIcon,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(md_.MdWorkHistory, {
                                                size: 20,
                                                className: Icon
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: Title,
                                                children: "Office Hours"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: Desc,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: " font-semibold",
                                                children: "M-F"
                                            }),
                                            ":8:30am – 5:00pm"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: Desc,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: " font-semibold ml-[-2px]",
                                                children: "SAT"
                                            }),
                                            ":8:30am – 2:00pm"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: miniDataBox,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: titleIcon,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(ai_.AiFillMessage, {
                                                size: 20,
                                                className: Icon
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: Title,
                                                children: "Contact"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        href: "tel:+03-4328-5546",
                                        className: Desc,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-semibold",
                                                children: "Phone:"
                                            }),
                                            " (03) 4328 5546"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        className: Desc,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-semibold",
                                                children: "Email:"
                                            }),
                                            " info@storagex.com.au"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: miniDataBox,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: titleIcon,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(si_.SiOpenaccess, {
                                                size: 20,
                                                className: Icon,
                                                color: "black"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: Title,
                                                children: "Access Hours"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: Desc,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-xl font-bold",
                                            children: "5:00am to 10:00pm"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-[80%] ml-auto mr-auto sm:w-[60%] md:w-[50%] lg:w-[100%] lg:mr-0 lg:ml-0 lg:mt-20 relative",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_responsive_carousel_namespaceObject.Carousel, {
                    className: " rounded-xl",
                    showThumbs: false,
                    showIndicators: false,
                    swipeable: true,
                    showStatus: false,
                    autoPlay: true,
                    infiniteLoop: true,
                    children: array.map((item, index)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: item,
                                alt: "Image of people packing"
                            })
                        }, index);
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const locationInfo_LocationInfo = (LocationInfo);
const Container = external_classnames_default()("");
const mainDataContainer = external_classnames_default()("grid grid-cols-1 gap-5 mt-10 w-[60%] ml-auto mr-auto  sm:w-[80%]  sm:grid-cols-2    lg:gap-10 lg:ml-0 lg:mr-0 lg:w-[90%] xl:w-[80%]");
// const Col = classNames('mt-10 flex flex-col gap-10 w-[300px] ')
const miniDataBox = external_classnames_default()("text-white   px4 py-4 rounded-lg  flex flex-col justify-center items-center bg-[#e6b42d] ");
const Title = external_classnames_default()("text-2xl ");
const Desc = external_classnames_default()("text-lg mb-2 inline text-center");
const titleIcon = external_classnames_default()("flex items-center gap-2 mb-2 ");
const Icon = external_classnames_default()("font-bold text-black ");


/***/ }),

/***/ 1406:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ourUnits_OurUnits)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: external "react-icons/io"
const io_namespaceObject = require("react-icons/io");
// EXTERNAL MODULE: ./public/images/Box1.png
var Box1 = __webpack_require__(8597);
// EXTERNAL MODULE: ./public/images/Box2.png
var Box2 = __webpack_require__(582);
// EXTERNAL MODULE: ./public/images/Box3.png
var Box3 = __webpack_require__(4769);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-icons/si"
var si_ = __webpack_require__(764);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: ./context/DataContext.tsx
var DataContext = __webpack_require__(8034);
;// CONCATENATED MODULE: ./Components/ourUnits/Unit.tsx












const Unit = (props)=>{
    const [Anim, SetAnim] = (0,external_react_.useState)(false);
    const { setOpenCTA , setSelectedUnit  } = external_react_default().useContext(DataContext/* default */.Z);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " text-center border-[5px] rounded-lg border-[#e6b42d] xl:grid xl:grid-cols-3 xl:items-start xl:w-[60%]",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-10 xl:px-8 py-2 flex flex-col justify-center ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: Title,
                        children: props.Data.size_category
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "opacity-9 text-lg font-bold mt-1 mb-1 ",
                        children: [
                            props.Data.length,
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-md font-light",
                                children: "m"
                            }),
                            " X ",
                            props.Data.width,
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-md font-light",
                                children: "m"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-md text-bold w-[200px] ml-auto mr-auto ",
                        children: [
                            "Unit ",
                            props.Data.description
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: " text-md mb-3",
                        children: props.Data.type_category
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: titleIcon,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(si_.SiOpenaccess, {
                                color: "#e6bb2d"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: Desc,
                                children: "7 days Access"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: titleIcon,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiAlarmWarningFill, {
                                color: "#e6bb2d"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: Desc,
                                children: "Alarmed"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: titleIcon,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiLockPasswordFill, {
                                color: "#e6bb2d"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: Desc,
                                children: "Coded keypads"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-8 py-2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: Title,
                        children: "Price"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                className: "text-2xl font-bold text-[#e6bb2d] xl:text-4xl",
                                children: [
                                    "$",
                                    props.Data.monthly_rack_rate
                                ]
                            }),
                            " per month"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-1 mb-2 justify-center xl:mt-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(bs_.BsClockFill, {
                                color: "#e6bb2d"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-sm",
                                children: [
                                    props.Data.total_vacant,
                                    " Spaces left!"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                onClick: ()=>{
                    setSelectedUnit(props.Data);
                    setOpenCTA(true);
                },
                onMouseEnter: ()=>{
                    SetAnim(true);
                },
                onMouseLeave: ()=>{
                    SetAnim(false);
                },
                className: "border-t-[5px] flex h-[100%] flex-col items-center gap-4 px-4 py-4 cursor-pointer text-xl border-[#e6bb2d] border-r-0 hover:bg-[#e6b42d] transition-color duration-300 xl:border-l-[5px] xl:border-t-0",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex items-center justify-center gap-4 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "font-bold",
                                children: "Select Unit"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(io_namespaceObject.IoIosArrowDown, {
                                color: "#e6bb2d"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: props.Data.size_category.toLowerCase() == "small" ? Box1/* default */.Z : props.Data.size_category.toLowerCase() == "x-large" ? Box3/* default */.Z : Box2/* default */.Z,
                        className: `${Anim ? "animate-FlyAnimSlowSlow" : ""} w-[80%]`,
                        alt: "3D image of the container unit"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const ourUnits_Unit = (Unit);
const Title = external_classnames_default()("text-xl xl:text-2xl ");
const Desc = external_classnames_default()("text-sm xl:text-lg ");
const titleIcon = external_classnames_default()("flex items-center gap-2 mb-2 ");

;// CONCATENATED MODULE: ./Components/ourUnits/OurUnits.tsx




const OurUnits = (props)=>{
    const [FilterSize, SetFilterSize] = (0,external_react_.useState)("All");
    const [FilteredUnits, SetFilteredUnits] = (0,external_react_.useState)([]);
    //Small 
    //Meduim
    //Large
    //Xlarge
    (0,external_react_.useEffect)(()=>{
        let DataToSet = props.Data;
        //Filter the props data according to the filter size choosen and then add it to the state
        if (FilterSize === "All") {
            DataToSet = props.Data;
        }
        if (FilterSize === "Small") {
            DataToSet = props.Data.filter((item)=>item.size_category === "Small");
        }
        if (FilterSize === "Medium") {
            DataToSet = props.Data.filter((item)=>item.size_category === "Medium");
        }
        if (FilterSize === "Large") {
            DataToSet = props.Data.filter((item)=>item.size_category === "Large");
        }
        if (FilterSize === "X-Large") {
            DataToSet = props.Data.filter((item)=>item.size_category === "X-Large");
        }
        //Order Filtered Units by price
        SetFilteredUnits(DataToSet.sort((a, b)=>a.monthly_rack_rate - b.monthly_rack_rate));
    }, [
        FilterSize,
        props.Data
    ]);
    const Sizes = [
        "All",
        "Small",
        "Medium",
        "Large",
        "X-Large"
    ];
    if (props.Data.length === 0) {
        /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-5xl text-center",
                children: "No Units Found"
            })
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "text-white bg-[#1a1a1a] mt-52 py-20 px-20 ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                ref: props.Ref,
                className: " text-5xl md:text-6xl lg:text-8xl text-center ",
                children: "Our Units"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-wrap justify-center gap-4 mt-6",
                children: Sizes.map((item, index)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: ()=>{
                            SetFilterSize(item);
                        },
                        className: sizeBox + " " + (item === FilterSize ? sizeBoxSelected : ""),
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: " text-lg",
                            children: item
                        })
                    }, index);
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: " font-bold text-center mt-16",
                children: [
                    "Number of units: ",
                    FilteredUnits.length
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-wrap justify-center xl:flex-col gap-10 mt-8 items-center ",
                children: FilteredUnits.map((item, index)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx(ourUnits_Unit, {
                        Data: item
                    }, item.id);
                })
            })
        ]
    });
};
/* harmony default export */ const ourUnits_OurUnits = (OurUnits);
const sizeBox = external_classnames_default()("w-20 h-16 border-2 flex justify-center  items-center  border-[#e6bb2d] transition-all duration-300 cursor-pointer hover:bg-[#ecc956]  rounded-lg");
const sizeBoxSelected = external_classnames_default()("bg-[#e6bb2d] text-black");


/***/ }),

/***/ 8034:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ DataProvider),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const defualts = {
    OpenCTA: false,
    setOpenCTA: ()=>{},
    SelectedUnit: {
        id: -1,
        description: "",
        code: "",
        monthly_rack_rate: -1,
        type_category: "",
        size_category: "",
        total_vacant: -1,
        length: -1,
        width: -1
    },
    setSelectedUnit: ()=>{}
};
const DataContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext(defualts);
const DataProvider = ({ children  })=>{
    const [OpenCTA, setOpenCTA] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [SelectedUnit, setSelectedUnit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(defualts.SelectedUnit);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DataContext.Provider, {
        value: {
            OpenCTA,
            setOpenCTA,
            SelectedUnit,
            setSelectedUnit
        },
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DataContext);


/***/ }),

/***/ 4186:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Components_hero_Hero__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5064);
/* harmony import */ var _ComponentsShared_navbar_Navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7557);
/* harmony import */ var _Components_locationInfo_LocationInfo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2977);
/* harmony import */ var _Components_ourUnits_OurUnits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1406);
/* harmony import */ var _context_DataContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8034);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Components_form_Form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2094);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3590);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Components_form_Form__WEBPACK_IMPORTED_MODULE_7__, react_toastify__WEBPACK_IMPORTED_MODULE_8__]);
([_Components_form_Form__WEBPACK_IMPORTED_MODULE_7__, react_toastify__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function Home(props) {
    // let AccessToken = props.data.access_token;
    // let RefreshToken = props.data.refresh_token;
    const [Data, SetData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const unitesRef = (0,react__WEBPACK_IMPORTED_MODULE_6__.useRef)(null);
    const { OpenCTA  } = react__WEBPACK_IMPORTED_MODULE_6___default().useContext(_context_DataContext__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z);
    const [Error, SetError] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        state: false,
        message: ""
    });
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        localStorage.clear();
        //@ts-ignore
        if (props.dataGetter.message) {
            //@ts-ignore
            notify(props.dataGetter.message, "error");
        } else {
            let filteredData = props.dataGetter.filter((item)=>item.total_vacant > 0);
            SetData(filteredData);
        }
    //I want to filter the datagetter array to get data that has total-vacant > 0
    }, []);
    function notify(text, Type) {
        (0,react_toastify__WEBPACK_IMPORTED_MODULE_8__.toast)(text, {
            type: Type
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: " text-black ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ComponentsShared_navbar_Navbar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_8__.ToastContainer, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_hero_Hero__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                toJumpRef: unitesRef
            }),
            OpenCTA && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_form_Form__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-4 pt-20 sm:px-10 xl:px-20",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_locationInfo_LocationInfo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_ourUnits_OurUnits__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                Data: Data,
                Ref: unitesRef
            })
        ]
    });
}
//get static porps
// export async function getStaticProps() {
//   console.log(params);
let Token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiMGVkYzI1YzViZmJjZGFlODI0NmYxNTk5ZDY5MTc5MDI1Njk0NmU2YmQ3ZGUzZTI1MDI2Yjc4NDc4MzAwYzM4MDc5MWJlMTJiZjIyMjAiLCJpYXQiOjE2ODA1MzUwMTYuNjY2MjgsIm5iZiI6MTY4MDUzNTAxNi42NjYyODIsImV4cCI6MTcxMjE1NzQxNi42NTg2ODMsInN1YiI6IjIxMjUiLCJzY29wZXMiOltdfQ.n1efTyCmOGrZ8tQQjca2kmbj_6bSIvmJ5JAvjDGEKSRqyvMYCNtaRxq3E6_grsd4d8zZE4xyQu_c_GmK6AOd8XeUCo-3YNevtOswY6TVizP42ezbV4CpW0zNYkx_oIPNDswJJPDV38wbrtZH1z6wBmJ1WvuNFjwU76Te7A78gJQMzVTbMTUoS5WzUgTmOm-13HAwmfaL7KOO1MeJz9QclRiI1mNsP7_Wbr-ewlFXus0_eRWoBuLKN8XOeqFPZsDG5UFSbrBkdNxHVXGTeDyFfm6ykV8k43GZhP83-_vO1FofxGCPwz6cXKqnXDdikHRNzmc8Okuo0kwzqBMpTBtgKO4ci3pdODAwJ2lESZ9pLFm9jtnRa4b8h0HcAwiPEQGatoH4NVMGG7q78ahTymqdXqR60Mk4b8PFcYJBxDkruDJ7KAz-Dc2xviBC-puFib9_sK2QjLQDKalwf_quxi7v_Y7_pc5IgN3KJVtNtK5QsfFLHaGNP_7dLnFkvwZpKrXvgrvfTlCy9DqajAr5y6bUfScayMQ_zGGYokn5MLVcCZq_EuYmmBXvYgNnwQnmJNsKYpKYjg9PeQ_-o0Drda8rIuIN8lkFMMV4mqmy7pU_WNT4gsi27C5afgZgW6-chjvoNQfVDtz1hhuNl50dL_w2xlB3bFOBh_SYO7eliKUVNJw";
//   const headers = {
//     'Content-Type': 'application/json',
//     'Accept': 'application/json',
//     'Authorization': `Bearer ${Token} `
//   };
//   let data = await axios.get('https://cloud.storman.com/oauth/authorize?client_id=51&redirect_uri=https://storage-x.vercel.app/&response_type=code', { headers, withCredentials: true })
//   console.log(data);
//   return {
//     props: { data },
//   }
// }
async function getServerSideProps(context) {
    // let Token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiOTJiMGVkYzI1YzViZmJjZGFlODI0NmYxNTk5ZDY5MTc5MDI1Njk0NmU2YmQ3ZGUzZTI1MDI2Yjc4NDc4MzAwYzM4MDc5MWJlMTJiZjIyMjAiLCJpYXQiOjE2ODA1MzUwMTYuNjY2MjgsIm5iZiI6MTY4MDUzNTAxNi42NjYyODIsImV4cCI6MTcxMjE1NzQxNi42NTg2ODMsInN1YiI6IjIxMjUiLCJzY29wZXMiOltdfQ.n1efTyCmOGrZ8tQQjca2kmbj_6bSIvmJ5JAvjDGEKSRqyvMYCNtaRxq3E6_grsd4d8zZE4xyQu_c_GmK6AOd8XeUCo-3YNevtOswY6TVizP42ezbV4CpW0zNYkx_oIPNDswJJPDV38wbrtZH1z6wBmJ1WvuNFjwU76Te7A78gJQMzVTbMTUoS5WzUgTmOm-13HAwmfaL7KOO1MeJz9QclRiI1mNsP7_Wbr-ewlFXus0_eRWoBuLKN8XOeqFPZsDG5UFSbrBkdNxHVXGTeDyFfm6ykV8k43GZhP83-_vO1FofxGCPwz6cXKqnXDdikHRNzmc8Okuo0kwzqBMpTBtgKO4ci3pdODAwJ2lESZ9pLFm9jtnRa4b8h0HcAwiPEQGatoH4NVMGG7q78ahTymqdXqR60Mk4b8PFcYJBxDkruDJ7KAz-Dc2xviBC-puFib9_sK2QjLQDKalwf_quxi7v_Y7_pc5IgN3KJVtNtK5QsfFLHaGNP_7dLnFkvwZpKrXvgrvfTlCy9DqajAr5y6bUfScayMQ_zGGYokn5MLVcCZq_EuYmmBXvYgNnwQnmJNsKYpKYjg9PeQ_-o0Drda8rIuIN8lkFMMV4mqmy7pU_WNT4gsi27C5afgZgW6-chjvoNQfVDtz1hhuNl50dL_w2xlB3bFOBh_SYO7eliKUVNJw'
    // let data: {
    //   access_token: string,
    //   expires_in: number,
    //   refresh_token: string,
    //   token_type: string,
    // };
    // const requestOptions = {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    //   body: JSON.stringify({
    //     grant_type: "authorization_code",
    //     client_id: 52,
    //     client_secret: "qpiH1AxfUPI6EUO6MjoeJ9YYdoSVGjd8dtIL4Y3b",
    //     redirect_uri: "https://storage-x.vercel.app/",
    //     code: (context.query.code + "")
    //   })
    // };
    // let api = await fetch(`https://cloud.storman.com/oauth/token`, requestOptions)
    // data = await api.json()
    let apiGetter = await fetch(`${"https://cloud.storman.com/api/v1/facility/XSTOR"}/unit-types?is_active=true`, {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": `Bearer ${"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1MiIsImp0aSI6IjVhZjRjMTYyMjcyNmE4MzM0MGIzM2JmNzc4Y2MxY2JhNWViNjJjMzkzMGFhNWQ1MzMzMTdkNmQ3M2MxMmNjNDJmMDhkNTNlMjhlNTgwMTJiIiwiaWF0IjoxNjgxMzUyMTkwLjEyMTY5MSwibmJmIjoxNjgxMzUyMTkwLjEyMTY5MywiZXhwIjoxNzEyOTc0NTkwLjA5MzA2MSwic3ViIjoiMjEyNSIsInNjb3BlcyI6W119.BrmmVaxILgo-AwFIJfzhurK5yTvNIufTZj8hZP4Ji5U0APnmPy0n9lX6HiXOukM-lA-ydFh1PvgJr4R6YSSX-KS1_Jyrzsq3JOtnyQG-5NCfgpUKXVPRlVdeyR9JFI9cOhGnhUpfTSh0t3WaMxv_DCgFY044mH3ABUR9IGTDLzSod71g5Hch7KQaqmWVnQO1QCdy5P79X_5kCtsd0fvH7bK-JjdQEQP848nPcuRwHP_5pT97If23YIGLHAZjYt0-n8oXJsAokKrmPsjzjVxYIeZvOza5sTL1GMJcZIZdgWD-zVTUDXHckf_-BvTmd0VRlrcqo_Pr-INqI7Mg_3Z2fzkG06w7zSqpDDg-m0yuopr4GrozVs0_WbRRWnlGA96bnXIi4h06JWbVtEHJ0FPmDZPpek8NptqvsPPPSYv20NcV-dWRmmhZYCwBLSuE2Urzildr99FDJ7857Vtu85tb-NZbpCOG6KAE4yb9yyyTU7jP2FlAAzaB-O5KURWBwHIO5dbfBSFxPTGEOXtNddm42doL4E1tKfSUim4ZLMjjuXdPeQIh9NiCOpceC5q9Iw7MacgYuYs6QptGBj2S-nvD_SrxGV3Q4efa2pnV444STmLls16lXvPSN99aLrFErg6adLRGf9ULJBP8V5HULhWsnFps4kqcErskylys7LSiQSE"}`
        }
    });
    let dataGetter = await apiGetter.json();
    return {
        props: {
            dataGetter
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3559:
/***/ (() => {



/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 983:
/***/ ((module) => {

"use strict";
module.exports = require("react-datepicker");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 9989:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io5");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 764:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/si");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,121,452,840], () => (__webpack_exec__(4186)));
module.exports = __webpack_exports__;

})();