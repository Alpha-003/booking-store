import React from 'react'
import classNames from 'classnames'

type Props = {}

const Services = (props: Props) => {
  return (
    <div className='text-6xl '>Services</div>
  )
}

export default Services