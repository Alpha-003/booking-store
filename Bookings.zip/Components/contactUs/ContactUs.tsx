import React from 'react'
import classNames from 'classnames'

type Props = {}

const ContactUS = (props: Props) => {
  return (
    <div>ContactUS</div>
  )
}

export default ContactUS