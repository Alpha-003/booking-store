import React from 'react'
import classNames from 'classnames'

type Props = {}

const Projects = (props: Props) => {
  return (
    <div className='text-6xl '>Projects</div>
  )
}

export default Projects