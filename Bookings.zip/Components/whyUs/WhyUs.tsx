import React from 'react'
import classNames from 'classnames'

type Props = {}

const WhyUs = (props: Props) => {
  return (
    <div className='text-6xl '>WhyUs</div>
  )
}

export default WhyUs